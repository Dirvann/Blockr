package domain.block.interfaces;

public interface Cavity {

}
