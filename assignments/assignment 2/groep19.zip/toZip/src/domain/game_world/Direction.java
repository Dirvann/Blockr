package domain.game_world;

public enum Direction{
	UP,DOWN,LEFT,RIGHT
}