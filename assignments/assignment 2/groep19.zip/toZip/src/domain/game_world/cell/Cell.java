package domain.game_world.cell;

public abstract class Cell {

}
