package domain.game_world.cell;

public class EmptyCell extends Cell implements RobotCanEnter {

	public EmptyCell() {
		
	}
}
