package domain.game_world.cell;

public class Goal extends Cell implements RobotCanEnter {

	public Goal() {
		
	}
}
