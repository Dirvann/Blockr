package domain.game_world.cell;

public interface RobotCanEnter {

}
