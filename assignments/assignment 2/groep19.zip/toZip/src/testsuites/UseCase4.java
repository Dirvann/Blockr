package testsuites;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/**
 * Our current implementation does not allow to test this without opening a window.
 * Planned changes:
 * 	1. Make a class that can recieve input in between the key events and the presentation class.
 *  2. Everything needs to be independent of canvas for testing. 
 *  	I should be able to use the class from (1) and block locations to test without the GUI.
 */
class UseCase4 {
	
	@Test
	void test() {
		fail("Unfinished structure");
	}

}
