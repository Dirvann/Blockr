package game_world.api;

public enum ActionResult {
	Success,
	UnknownAction,
	Illegal,
	GoalReached,
}
