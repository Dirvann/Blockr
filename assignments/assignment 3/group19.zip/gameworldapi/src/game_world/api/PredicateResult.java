package game_world.api;

public enum PredicateResult {
	True,
	False,
	BadPredicate,
}
