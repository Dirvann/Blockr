package exceptions;

public class OutOfBoundsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3854452415157499263L;

}
