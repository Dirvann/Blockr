package game_world.api;

/**
 * 
 * Implement Action to allow the controller to execute 
 * actions in the GameWorld.
 */
public interface Action extends Message {
	
}
