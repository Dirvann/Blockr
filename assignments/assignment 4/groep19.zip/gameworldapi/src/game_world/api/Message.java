package game_world.api;

public interface Message {
	public String getName();
}
