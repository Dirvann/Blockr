package game_world.api;

/**
 * 
 * Implement Predicate to allow the controller to evaluate 
 * predicates in the GameWorld.
 */
public interface Predicate extends Message {
	
}
