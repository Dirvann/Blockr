package game_world.api;

/**
 * 
 * Result given after evaluation of a predicate.
 */
public enum PredicateResult {
	True,
	False,
	BadPredicate,
}
