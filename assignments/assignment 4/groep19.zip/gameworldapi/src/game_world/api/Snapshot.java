package game_world.api;

/**
 * 
 * Implement Snapshot to allow the controller to create 
 * snapshots of the GameWorld.
 */
public interface Snapshot {
	
}
