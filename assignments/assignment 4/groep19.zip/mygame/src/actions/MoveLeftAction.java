package actions;
import game_world.api.Action;

public class MoveLeftAction implements Action{
	public String getName() {
		return "Move Left";
	}
}
