package actions;

import game_world.api.Action;

public class MoveRightAction implements Action{
	public String getName() {
		return "Move Right";
	}
}
