package actions;

import game_world.api.Action;

public class StandStillAction implements Action{
	public String getName() {
		return "Stand Still";
	}
}
