package predicates;

import game_world.api.Predicate;

public class BlockAbovePlayerPredicate implements Predicate {
	public String getName() {
		return "Block Above Player";
	}
}
