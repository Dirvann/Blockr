package game_world.cell;

public interface RobotCanEnter {

}
