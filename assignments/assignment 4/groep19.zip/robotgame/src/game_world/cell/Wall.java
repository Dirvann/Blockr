package game_world.cell;

public class Wall extends Cell {

}
